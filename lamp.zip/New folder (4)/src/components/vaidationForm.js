import React from 'react';
import { FiLogIn } from "react-icons/fi";

const initialState ={
        email:"",
        password:"",
        confirmPassword:"",
        captcha:"",
        emailError:"",
        passwordError:"",
        confirmPasswordError:"",
        captchaError:"",
      };
    
    const emailRegex= RegExp(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
    const passwordRegex = RegExp(/^[A-Za-z]\w{7,14}$/);
class ValidationForm extends React.Component {
    state =initialState;

    handleChange = (event) =>{
        const check= event.target.type ==="checkbox";
        this.setState({
           [event.target.name]: check ? event.target.checked : event.target.value
        });
        
        switch(event.target.name){
        case('email'):
        this.state.emailError= emailRegex.test(event.target.value)?"":"Invalid email";
        break;

        case('password'):
        this.state.passwordError=  passwordRegex.test(event.target.value)?"":"password should be 7 to 15 characters which contain only characters, numeric digits, underscore and first character must be a letter";
        break;

        case('confirmPassword'):
        this.state.confirmPasswordError= this.state.password === event.target.value ? '' :"it does not match!";
        break;

        default:
            break;
      
    }
      };
    
    
    validate =()=>{
       if(this.state.emailError || this.setState.passwordError || this.state.confirmPasswordError){
           return false;
       }

       else if(!this.state.email || !this.state.password || !this.state.confirmPassword || !this.state.captcha)
       {
           alert("Please fill all fields!");
           return false;
       }

       return true;
    };


     handleSubmit = event =>{
        event.preventDefault();
       
        console.log(this.state);
        const isValid=this.validate()
        if(isValid){
            console.log("valid!");
            this.setState(initialState);
            //window.location.href="/home";
        }

        else{
            console.log("invalid");
        }
       };

       
    render(){
    return(
        <div className="form-wrapper">
    <form  onSubmit= {this.handleSubmit} noValidate>
        <div className="item-wrapper">
            <input type="Email" className="formItem" placeholder="EMAIL" name="email" value={this.state.email}
            onChange={this.handleChange}  />
            <div className="form-error">{this.state.emailError}</div>
        </div> 

        <div className="item-wrapper">
            <input type="password" className="formItem" placeholder="PASSWORD" name="password" value={this.state.password}
            onChange={this.handleChange} />
            <div className="form-error">{this.state.passwordError}</div>
            
        </div>
        
        <div className="item-wrapper">
            <input type="password" className="formItem" placeholder="CONFIRM_PASSWORD" name="confirmPassword"  value={this.state.confirmPassword}
            onChange={this.handleChange} />
            <div className="form-error">{this.state.confirmPasswordError}</div>

        </div>

        <div className="item-wrapper">
            <input type="text" className="formItem" placeholder="CAPTCHA" name="captcha" value={this.state.captcha}
            onChange={this.handleChange} />
            
            <div className="form-error">{this.state.captchaError}</div>
           
        </div>


        <div >
        <button type="submit" className="login-btn">SignUp  <FiLogIn size={"15"} /></button>
        </div>

    </form>
    </div>
    
    );}

 }

export default ValidationForm;