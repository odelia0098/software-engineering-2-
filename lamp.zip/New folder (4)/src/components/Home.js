import React from 'react';
const Home = () => {
    return(
        <div>
            <span>HOME</span>
        </div>
    );

 }
  
 export default Home;
